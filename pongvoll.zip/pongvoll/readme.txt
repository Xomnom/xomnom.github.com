PONG VOLLEYBALL

Xomnom
https://gist.github.com/xomnom

target platform: DOSBox


screen guide:
       grey - walls, ceiling, net
     yellow - floors
      white - balls
      green - paddles
  blue, red - projectiles
    magenta - score
       cyan - meter

objective:
	Score five (or more) points to win the match.
	Point(s) are awarded when opponent faults.
	Letting a ball hit floor is a fault.
	Letting paddle hit a stationary projectile is a fault.
	New round starts after each fault.

universal controls:
     escape - force-quit
P1 controls:
	  W - up
	  A - left
	  D - right
	  S - special
P2 controls:
   up arrow - up
 left arrow - left
right arrow - right
 down arrow - special

special meter:
	Meter charges when balls hit opponent's ceiling; overflow depletes.
	Pressing "down" stops paddle if in motion.  If already stationary,
	if at least 30% meter and you haven't six already, subtracts that much
	meter and deploys a projectile; otherwise activates doubling cube if
	permitted.  Single fault may be canceled with 60% meter.

projectiles:
	Travels to opponent's side when deployed (blue); specials cannot be
		activated by either player until projectile reaches
		destination and becomes stationary (red).
	Deliberately nameless; come up with your own nickname.

doubling cube:
	Please refer to Wikipedia for explanation:
		http://en.wikipedia.org/wiki/Backgammon#Doubling_cube
	Crawford rule is in effect; "beaver", "raccoon", other rules aren't.
	Extra balls appear at double and octuple stakes.
	Stakes, projectiles, extra balls, etc. reset at new round.

collision physics:
	Net, stationary paddle bounces balls � la Pong / Breakout.
	Stationary projectile sends ball down.
	Moving paddle bounces balls erratically (but always up).

hints:
	Frame rate is a little under 20 FPS.
	Only positive-edge keystrokes are processed; auto-repeat is
		deliberately at default, non-useful setting to discourage
		holding keys down.
	Input is ignored during long beeps.
	Spawn positions in new rounds depend upon prior positions.
	Projectiles won't deploy if below top of net.
	Doubling becomes a good idea with roughly three-to-one favorable odds.
	Paddles can't chase balls downward, so be careful when venturing high.
	I'm really paranoid about having missed something here.
